$(function() {

  var t = { 
//
"Download Section": {
    en: "Download Section",
    ro: "Sectiunea Descarca",
	it:"",
	fr:"",
	de:""
  },
//
"Free downloads section. Our APP is currently provided only Windows compatible files.": {
    en: "Free downloads section. Our APP is currently provided only Windows compatible files.",
    ro: "Secțiunea de descărcări gratuite. Aplicația în prezent furnizată numai fișiere compatibile cu sistemul de operare Windows.",
	it:"",
	fr:"",
	de:""
  },
//
"Package": {
    en: "Package",
    ro: "Pachet",
	it:"",
	fr:"",
	de:""
},

//
"Download": {
    en: "Download",
    ro: "Descarca",
	it:"",
	fr:"",
	de:""
},
//
"Chaturbate Bio design": {
    en: "Chaturbate Bio design",
    ro: "Design Bio Chaturbate",
	it:"",
	fr:"",
	de:""
},
//
"Check back from time to time to access new downloads when we make them available": {
    en: "Check back from time to time to access new downloads when we make them available",
    ro: "Reveniți din când în când pentru a accesa descărcări noi atunci când le punem la dispoziție",
	it:"",
	fr:"",
	de:""
},
//
" ": {
    en: " ",
    ro: " ",
	it:"",
	fr:"",
	de:""
},
//
" ": {
    en: " ",
    ro: " ",
	it:"",
	fr:"",
	de:""
},
//
" ": {
    en: " ",
    ro: " ",
	it:"",
	fr:"",
	de:""
},  
  
  
  
  
  
  
  
  
  
  
  
  
  
// Help Modal
"Heed Help?": {
	en: "Heed Help?",
    ro: "Ai nevoie de ajutor?",
	it:"",
	fr:"",
	de:""
},
"Change the language of the content using EN (English) or RO (Romanian) options": {
	en: "Change the language of the content using EN (English) or RO (Romanian) options",
    ro: "Shimba continutul in limba Romana (RO) sau Engleza (EN) folosind optiunile afisate",
	it:"",
	fr:"",
	de:""
},
"Icons": {
	en: "Icons",
    ro: "Legenda Iconite",
	it:"",
	fr:"",
	de:""
},
"Contact us if necessary": {
	en: "Contact us if necessary",
    ro: "Daca este necesar ne poti contacta",
	it:"",
	fr:"",
	de:""
},
"Close": {
	en: "Close",
    ro: "Inchide",
	it:"",
	fr:"",
	de:""
},
"Using external style sheet (MyFreeCams)": {
	en: "Using external style sheet (MyFreeCams)",
    ro: "MyFreeCams si foaia de stil externa",
	it:"",
	fr:"",
	de:""
},
"Because MyFreeCams allows additional css, when using the Editor Tool, wrap the CSS markup between": {
	en: "Because MyFreeCams allows additional css, when using the Editor Tool, wrap the CSS markup between",
    ro: "Deoarece MyFreeCams foloseste foaie de stil externa, in Editor va trebui sa adaugi si css-ul intre etichetele",
	it:"",
	fr:"",
	de:""
},
"and": {
	en: "and",
    ro: "si",
	it:"",
	fr:"",
	de:""
},
"tags followed by HTML markup": {
	en: "tags followed by HTML markup",
    ro: "urmat de codul HTML",
	it:"",
	fr:"",
	de:""
},
"Should look like this, inside the Editor tool": {
	en: "Should look like this, inside the Editor tool",
    ro: "In Editor ar trebui sa arate similar cu",
	it:"",
	fr:"",
	de:""
},

//Render Source 
//26 
 "Test markup codes and see how your browser is rendering them. Use": {
    en: "Test markup codes and see how your browser is rendering them. Use",
    ro: "Testați codurile de marcare și vedeți cum le redă browserul. Foloseste butonul",
	it:"",
	fr:"",
	de:""
  },
//27  
 "button to see how to use the source editor and rendering tool": {
    en: "button to see how to use the source editor and rendering tool",
    ro: "pentru a vedea mai multe informatii cum sa folosesti aceasta functie",
	it:"",
	fr:"",
	de:""
  },
//28    
"Markup Code Box": {
    en: "Markup Code Box",
    ro: "Caseta Cod Marcaj",
	it:"",
	fr:"",
	de:""
  },
//29     
"Show": {
    en: "Show",
    ro: "Arata",
	it:"",
	fr:"",
	de:""
  },
//30    
"Default": {
    en: "Default",
    ro: "Implicit",
	it:"",
	fr:"",
	de:""
  },
//31   
"Render Box": {
    en: "Render Box",
    ro: "Caseta Redare",
	it:"",
	fr:"",
	de:""
  },
//32  
 "That\'s how it looks rendered in browser. Optionally you can": {
    en: "That\'s how it looks rendered in browser. Optionally you can",
    ro: "Asa arata in browser. Optional",
	it:"",
	fr:"",
	de:""
  },
//33  
 "Save as PDF": {
    en: "Save as PDF",
    ro: "Salveaza ca PDF",
	it:"",
	fr:"",
	de:""
  },
//34         
"Default button, on click, removes the markup code from grey box above": {
    en: "Default button, on click, removes the markup code from grey box above",
    ro: "Butonul Implicit, sterge codul din caseta cu sursa codului",
	it:"",
	fr:"",
	de:""
  },  
  
 //39
 "How to use...": {
    en: "How to use...",
    ro: "Cum sa folosesti...",
	it:"",
	fr:"",
	de:""
  },
//40  
 "Paste markup codes showed on page inside the Markup Code Box (top box)": {
    en: "Paste markup codes showed on page inside the Markup Code Box (top box)",
    ro: "Adauga codul de marcaj in caseta din stanga, Caseta Cod Marcaj",
	it:"",
	fr:"",
	de:""
  },
//41     
 "Click on Show button": {
    en: "Click on Show button",
    ro: "Click pe butonul Arata",
	it:"",
	fr:"",
	de:""
  },
//42   
 "View the rendered markup inside the Render Box (below)": {
    en: "View the rendered markup inside the Render Box (below)",
    ro: "In caseta din dreapta, Caseta Redare, poti vedea cum este interpretat de catre browser codul sursa",
	it:"",
	fr:"",
	de:""
  },
//43     
 "Show button allows you to start rendering the markup code": {
    en: "Show button allows you to start rendering the markup code",
    ro: "Butonul Arata, vă permite să începeți redarea codului de marcare",
	it:"",
	fr:"",
	de:""
  },
//44     
"Default button is used as reset the Markup Code box, all input will be lost": {
    en: "Default button is used as reset the Markup Code box, all input will be lost",
    ro: "Butonul Implicit este utilizat ca resetare a casetei Cod de Marcaj, continutul din aceasta fereastra va fi sters",
	it:"",
	fr:"",
	de:""
  },
//45    
"Print this page as pdf - well, you don\'t need much but its there, just in case. Please note, the print page will only print content from Render Box.": {
    en: "Print this page as pdf - well, you don\'t need much but its there, just in case. Please note, the print page will only print content from Render Box.",
    ro: "Salveaza ca pdf - ei bine, nu este nevoie, dar este acolo. Vă rugăm, rețineți, pagina de imprimare va imprima doar conținut din Caseta Redare.",
	it:"",
	fr:"",
	de:""
  },   
//
"Close": {
    en: "Close",
    ro: "Inchide",
	it:"",
	fr:"",
	de:""
  }, 
  
//Modal Translate
  "Change Language": {
	en: "Change Language",
    ro: "Schimba limba",
	it:"Cambia lingua",
	fr:"Changer de langue",
	de:""
  },
  
   "Change the content of the material in your preferred language": {
    en: "Change the content of the material in your preferred language",
	ro: "Schimba continutul materialului in limba preferata",
	it:"Cambia il contenuto del materiale nella tua lingua preferita",
	fr:"Changer le contenu du matériel dans votre langue préférée",
	de:""
  },
  
  "Romanian": {
    en: "Romanian",
    ro: "Romana",
	it: "Rumena",
	fr: "Roumaine",
	de: "Rumänische"
  },
  "English": {
    en: "English",
	ro: "Engleza",
	it: "Inglese",
	fr: "Anglaise",
	de: "Englische"
  },
  
 "French": {
	en: "French",
    ro: "Franceza",
	it: "Francese",
	fr: "Français",
	de: "Französische"
  },
   
   "Italian": {
    en: "Italian",
	ro: "Italiana",
	it: "Italiano",
	fr: "Italien",
	de: "Italienisch"
  },
  "German": {
    en: "German",
    ro: "Germana",
	it: "Tedesca",
	fr: "Allemand",
	de: "Deutsch"
  },  
  
 "Help translate this material": {
    en:"Help translate this material",
	ro:"Ajuta la traducerea acesui material",
	it:"Aiuta a tradurre questo materiale",
	fr:"Aidez à traduire ce matériel",

	de:"Hilf mit, dieses Material zu übersetzen"
  },  

}
  
  
  
  var _t = $('body').translate({lang: "en", t: t});
  var str = _t.g("translate");
  console.log(str);


  $(".lang_selector").click(function(ev) {
    var lang = $(this).attr("data-value");
    _t.lang(lang);

    console.log(lang);
    ev.preventDefault();
  });



});



    
    

