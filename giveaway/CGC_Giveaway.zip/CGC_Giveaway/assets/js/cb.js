$(function() {

  var t = { 
//Header
  "About": {
    en: "About",
    ro: "Despre",
	it:"",
	fr:"",
	de:""
  },
//
"Giveaway": {
    en: "Giveaway",
    ro: "Oferta Gratuita",
	it:"",
	fr:"",
	de:""
  },  
//
"Info": {
    en: "Info",
    ro: "Info",
	it:"",
	fr:"",
	de:""
  },
//
"Chaturbate Giveaway - Info": {
    en: "Chaturbate Giveaway - Info",
    ro: "Pachetul gratuit Chaturbate - Info",
	it:"",
	fr:"",
	de:""
  },  
//
"Here you go, custom Chaturbate bio design Tory and all it\'s documentation to help you with editing and customization process. Please note, before installing the final code on Chaturbate platform make sure all images are uploaded online.": {
    en: "Here you go, custom Chaturbate bio design Tory and all it\'s documentation to help you with editing and customization process. Please note, before installing the final code on Chaturbate platform make sure all images are uploaded online.",
    ro: "Tory - design bio Chaturbate personalizat și toată documentația pentru a te ajuta cu procesul de editare și personalizare. Rețineți, înainte de a instala codul final pe platforma Chaturbate, asigurați-vă că toate imaginile sunt încărcate online.",
	it:"",
	fr:"",
	de:""
},
//
"Click the eye icon to show the template": {
    en: "Click the eye icon to show the template",
    ro: "Click pe iconita pentru a afisa designul",
	it:"",
	fr:"",
	de:""
  },
//
"Markup Code": {
    en: "Markup Code",
    ro: "Cod Marcaj",
	it:"",
	fr:"",
	de:""
},
//
"This is the full markup code which renders the magic of Tory Chaturbate bio design": {
    en: "This is the full markup code which renders the magic of Tory Chaturbate bio design",
    ro: "Acesta este codul complet de marcare care redă magia designului bio Tory Chaturbate",
	it:"",
	fr:"",
	de:""
},
//
"Try this markup in Source Editor tool": {
    en: "Try this markup in Source Editor tool",
    ro: "Testeaza acest cod in Editor",
	it:"",
	fr:"",
	de:""
},


//
"Markup code": {
    en: "Markup code",
    ro: "Sursa cod de marcare",
	it:"",
	fr:"",
	de:""
  },
//
"All designs come with their own custom markup codes, please don\'t try to combine code snippets between designs or try to install a custom design for one platform to another platform. They are build and developed specifically for their respective service.": {
    en: "All designs come with their own custom markup codes, please don\'t try to combine code snippets between designs or try to install a custom design for one platform to another platform. They are build and developed specifically for their respective service.",
    ro: "Toate pachetele vin cu propriile coduri de marcare personalizate, nu încercați să combinați fragmente de cod între proiecte sau să încercați să instalați un design personalizat pentru o platformă pe o altă platformă. Sunt construite și dezvoltate special pentru serviciile respective.",
	it:"",
	fr:"",
	de:""
  },
  
////
//
"Take into consideration our suggestions regarding editing process for a faster, non-damaging and smooth customization.": {
	en: "Take into consideration our suggestions regarding editing process for a faster, non-damaging and smooth customization.",
    ro: "Puneți în practică sugestiile noastre cu privire la procesul de editare pentru o personalizare mai rapidă și fără probleme.",
	it:"",
	fr:"",
	de:""
},  
//
"Before installing the markup code on Chaturbate platform, for better positioning of the layout, change the first main values form main style with:": {
	en: "Before installing the markup code on Chaturbate platform, for better positioning of the layout, change the first main values form main style with:",
    ro: "Înainte de a instala codul pe platforma Chaturbate, pentru o mai bună poziționare a designului, schimbați primele valori principale din stilul main cu:",
	it:"",
	fr:"",
	de:""
},  
//
"Go to images folder and upload all of them online. Use your favorite hosting provider.": {
	en: "Go to images folder and upload all of them online. Use your favorite hosting provider.",
    ro: "Accesați folderul de imagini și încărcați-le pe toate. Recomandam un serviciu de incredere sau host personal.",
	it:"",
	fr:"",
	de:""
},
//
"Replace the full path of the image inside the source markup. Test your final code before adding it to Chaturbate.": {
	en: "Replace the full path of the image inside the source markup. Test your final code before adding it to Chaturbate.",
    ro: "Înlocuiți imaginile din design editand codul sursa. Testați codul final înainte de instalare pe Chaturbate.",
	it:"",
	fr:"",
	de:""
},  
//
"The Source Editor comes with a small but intuitive documentation on how to use it.": {
	en: "The Source Editor comes with a small but intuitive documentation on how to use it.",
    ro: "Editorul sursă vine cu documentare simpla, dar intuitivă referitor la cum să il folosești.",
	it:"",
	fr:"",
	de:""
},  
//
"Graphic resources": {
    en: "Graphic resources",
    ro: "Resurse grafice",
	it:"",
	fr:"",
	de:""
  },
// 
"Even if this package is a free one, you need to host images.": {
    en: "Even if this package is a free one, you need to host images.",
    ro: "Chiar dacă acest pachet este unul gratuit, trebuie să găzduiești imagini.",
	it:"",
	fr:"",
	de:""
},
//
"Each design comes with their image folder. Upload your graphics online, copy and replace the full url path inside the source markup.": {
    en: "Each design comes with their image folder. Upload your graphics online, copy and replace the full url path inside the source markup.",
    ro: "Fiecare design vine cu folderul sau de resurse. Încărcați imaginile online, copiați și înlocuiți calea URL completă in marcajul sursă.",
	it:"",
	fr:"",
	de:""
  },
//
"Source editor": {
	en: "Source editor",
    ro: "Editor sursa cod",
	it:"",
	fr:"",
	de:""
  },
//
"If you are not familiar with markup editing or have no WYSIWYG markup editor installed on your machine, the Source Editor might be helpful becaus it allows you to see the markup code and edit it accordingly; ther\'s also a Preview function which renders your editing process in live browser based output.": {
	en: "If you are not familiar with markup editing or have no WYSIWYG markup editor installed on your machine, the Source Editor might be helpful becaus it allows you to see the markup code and edit it accordingly; ther\'s also a Preview function which renders your editing process in live browser based output.",
    ro: "Dacă nu sunteți familiarizat cu editarea marcajului sau nu aveți niciun editor de marcare WYSIWYG instalat pe laptopul/pc-ul dvs., Editorul Sursă poate fi util, deoarece vă permite să vedeți codul de marcare și să îl editați în consecință; de asemenea există și o funcție Previzualizare care redă din procesul de editare în browser.",
	it:"",
	fr:"",
	de:""
},
    
// Footer
"app v: 1.0": {
	en: "app v: 1.0",
    ro: "versiune: 1.0",
	it:"",
	fr:"",
	de:""
}, 



//





//Render Source 
//26 
 "Test markup codes and see how your browser is rendering them. Use": {
    en: "Test markup codes and see how your browser is rendering them. Use",
    ro: "Testați codurile de marcare și vedeți cum le redă browserul. Foloseste butonul",
	it:"",
	fr:"",
	de:""
  },
//27  
 "button to see how to use the source editor and rendering tool": {
    en: "button to see how to use the source editor and rendering tool",
    ro: "pentru a vedea mai multe informatii cum sa folosesti aceasta functie",
	it:"",
	fr:"",
	de:""
  },
//28    
"Markup Code Box": {
    en: "Markup Code Box",
    ro: "Caseta Cod Marcaj",
	it:"",
	fr:"",
	de:""
  },
//29     
"Show": {
    en: "Show",
    ro: "Arata",
	it:"",
	fr:"",
	de:""
  },
//30    
"Default": {
    en: "Default",
    ro: "Implicit",
	it:"",
	fr:"",
	de:""
  },
//31   
"Render Box": {
    en: "Render Box",
    ro: "Caseta Redare",
	it:"",
	fr:"",
	de:""
  },
//32  
 "That\'s how it looks rendered in browser. Optionally you can": {
    en: "That\'s how it looks rendered in browser. Optionally you can",
    ro: "Asa arata in browser. Optional",
	it:"",
	fr:"",
	de:""
  },
//33  
 "Save as PDF": {
    en: "Save as PDF",
    ro: "Salveaza ca PDF",
	it:"",
	fr:"",
	de:""
  },
//34         
"Default button, on click, removes the markup code from grey box above": {
    en: "Default button, on click, removes the markup code from grey box above",
    ro: "Butonul Implicit, sterge codul din caseta cu sursa codului",
	it:"",
	fr:"",
	de:""
  },  
  
 //39
 "How to use...": {
    en: "How to use...",
    ro: "Cum sa folosesti...",
	it:"",
	fr:"",
	de:""
  },
//40  
 "Paste markup codes showed on page inside the Markup Code Box (top box)": {
    en: "Paste markup codes showed on page inside the Markup Code Box (top box)",
    ro: "Adauga codul de marcaj in caseta din stanga, Caseta Cod Marcaj",
	it:"",
	fr:"",
	de:""
  },
//41     
 "Click on Show button": {
    en: "Click on Show button",
    ro: "Click pe butonul Arata",
	it:"",
	fr:"",
	de:""
  },
//42   
 "View the rendered markup inside the Render Box (below)": {
    en: "View the rendered markup inside the Render Box (below)",
    ro: "In caseta din dreapta, Caseta Redare, poti vedea cum este interpretat de catre browser codul sursa",
	it:"",
	fr:"",
	de:""
  },
//43     
 "Show button allows you to start rendering the markup code": {
    en: "Show button allows you to start rendering the markup code",
    ro: "Butonul Arata, vă permite să începeți redarea codului de marcare",
	it:"",
	fr:"",
	de:""
  },
//44     
"Default button is used as reset the Markup Code box, all input will be lost": {
    en: "Default button is used as reset the Markup Code box, all input will be lost",
    ro: "Butonul Implicit este utilizat ca resetare a casetei Cod de Marcaj, continutul din aceasta fereastra va fi sters",
	it:"",
	fr:"",
	de:""
  },
//45    
"Print this page as pdf - well, you don\'t need much but its there, just in case. Please note, the print page will only print content from Render Box.": {
    en: "Print this page as pdf - well, you don\'t need much but its there, just in case. Please note, the print page will only print content from Render Box.",
    ro: "Salveaza ca pdf - ei bine, nu este nevoie, dar este acolo. Vă rugăm, rețineți, pagina de imprimare va imprima doar conținut din Caseta Redare.",
	it:"",
	fr:"",
	de:""
  },   
//
"Close": {
    en: "Close",
    ro: "Inchide",
	it:"",
	fr:"",
	de:""
  },
  
  
// Help Modal
"Heed Help?": {
	en: "Heed Help?",
    ro: "Ai nevoie de ajutor?",
	it:"",
	fr:"",
	de:""
},
"Change the language of the content using EN (English) or RO (Romanian) options": {
	en: "Change the language of the content using EN (English) or RO (Romanian) options",
    ro: "Shimba continutul in limba Romana (RO) sau Engleza (EN) folosind optiunile afisate",
	it:"",
	fr:"",
	de:""
},
"Icons": {
	en: "Icons",
    ro: "Legenda Iconite",
	it:"",
	fr:"",
	de:""
},
"Contact us if necessary": {
	en: "Contact us if necessary",
    ro: "Daca este necesar ne poti contacta",
	it:"",
	fr:"",
	de:""
},

   
  
//Modal Translate
  "Change Language": {
	en: "Change Language",
    ro: "Schimba limba",
	it:"Cambia lingua",
	fr:"Changer de langue",
	de:""
  },
  
   "Change the content of the material in your preferred language": {
    en: "Change the content of the material in your preferred language",
	ro: "Schimba continutul materialului in limba preferata",
	it:"Cambia il contenuto del materiale nella tua lingua preferita",
	fr:"Changer le contenu du matériel dans votre langue préférée",
	de:""
  },
  
  "Romanian": {
    en: "Romanian",
    ro: "Romana",
	it: "Rumena",
	fr: "Roumaine",
	de: "Rumänische"
  },
  "English": {
    en: "English",
	ro: "Engleza",
	it: "Inglese",
	fr: "Anglaise",
	de: "Englische"
  },
  
 "French": {
	en: "French",
    ro: "Franceza",
	it: "Francese",
	fr: "Français",
	de: "Französische"
  },
   
   "Italian": {
    en: "Italian",
	ro: "Italiana",
	it: "Italiano",
	fr: "Italien",
	de: "Italienisch"
  },
  "German": {
    en: "German",
    ro: "Germana",
	it: "Tedesca",
	fr: "Allemand",
	de: "Deutsch"
  },  
  
 "Help translate this material": {
    en:"Help translate this material",
	ro:"Ajuta la traducerea acesui material",
	it:"Aiuta a tradurre questo materiale",
	fr:"Aidez à traduire ce matériel",

	de:"Hilf mit, dieses Material zu übersetzen"
  },  

}
  
  
  
  var _t = $('body').translate({lang: "en", t: t});
  var str = _t.g("translate");
  console.log(str);


  $(".lang_selector").click(function(ev) {
    var lang = $(this).attr("data-value");
    _t.lang(lang);

    console.log(lang);
    ev.preventDefault();
  });



});



    
    

