$(function() {

  var t = { 
//
"Behind the project": {
    en: "Behind the project",
    ro: "Din culise",
	it:"",
	fr:"",
	de:""
  },
//
"A few lines about this package and the author": {
    en: "A few lines about this package and the author",
    ro: "Cateva informatii despre acest material si autori",
	it:"",
	fr:"",
	de:""
  },
//
"About the App": {
    en: "About the App",
    ro: "Despre aplicatie",
	it:"",
	fr:"",
	de:""
},
//
"Build with Electron/Node.js compatible with Windows operating system": {
    en: "Build with Electron/Node.js compatible with Windows operating system",
    ro: "Dezvoltata folosind Electron si Node.js compatibil cu sistemul de operare Windows",
	it:"",
	fr:"",
	de:""
},
//
"Renders web-based pages build with Bootstrap 4.x framework": {
    en: "Renders web-based pages build with Bootstrap 4.x framework",
    ro: "Continutul este redat de pagini web construite folosind Bootstrap 4.x",
	it:"",
	fr:"",
	de:""
},
//
"Windows Key": {
    en: "Windows Key",
    ro: "Combinatii taste",
	it:"",
	fr:"",
	de:""
},
//
"Keyboard shortcut": {
    en: "Keyboard shortcut",
    ro: "Combinatii tastatura",
	it:"",
	fr:"",
	de:""
},
//
"Action": {
    en: "Action",
    ro: "Functie",
	it:"",
	fr:"",
	de:""
},
//
"Copy": {
    en: "Copy",
    ro: "Copiaza",
	it:"",
	fr:"",
	de:""
},
//
"Paste": {
    en: "Paste",
    ro: "Lipeste",
	it:"",
	fr:"",
	de:""
},
//
"Reload or Refresh": {
    en: "Reload or Refresh",
    ro: "Reincarca pagina",
	it:"",
	fr:"",
	de:""
},
//
"Toogle Full Screen": {
    en: "Toogle Full Screen",
    ro: "Mareste ecranul",
	it:"",
	fr:"",
	de:""
},
//
"Minimize": {
    en: "Minimize",
    ro: "Micsoreza sau ascunde ecranul",
	it:"",
	fr:"",
	de:""
},
//
"Close": {
    en: "Close",
    ro: "Inchide",
	it:"",
	fr:"",
	de:""
},
//
"Top-Right buttons": {
    en: "Top-Right buttons",
    ro: "Butoanele dreapta-sus",
	it:"",
	fr:"",
	de:""
},
//
"minimize window": {
    en: "minimize window",
    ro: "micsoreaza fereastra",
	it:"",
	fr:"",
	de:""
},
//
"maximize window and Full Screen": {
    en: "maximize window and Full Screen",
    ro: "mareste fereastra sau dimensiune completa",
	it:"",
	fr:"",
	de:""
},
//
"close window, Close App": {
    en: "close window, Close App",
    ro: "inchide fereastra sau aplicatia",
	it:"",
	fr:"",
	de:""
},
//
"Quiting the App also available in Tray toolbar": {
    en: "Quiting the App also available in Tray toolbar",
    ro: "In bara de stare de pe desktop se poate inchide aplicatia, click pe iconita",
	it:"",
	fr:"",
	de:""
},
//
"Author": {
    en: "Author",
    ro: "Despre Autor",
	it:"",
	fr:"",
	de:""
},
//
"I\'m Dan N, experienced Web Designer with a demonstrated history of working in the internet environment and  adult industry.": {
    en: "I\'m Dan N, experienced Web Designer with a demonstrated history of working in the internet environment and  adult industry.",
    ro: "Sunt Dan N, web designer cu portofoliu demonstrată a activității în mediul online și în industria adult web-design și web development.",
	it:"",
	fr:"",
	de:""
},
//
"Professional achievements:": {
    en: "Professional achievements:",
    ro: "Realizari profesionale:",
	it:"",
	fr:"",
	de:""
},
//
"Finalist 2018 XBIZ Awards - Innovative Web Product of the Year": {
    en: "Finalist 2018 XBIZ Awards - Innovative Web Product of the Year",
    ro: "Finalist 2018 XBIZ Awards - Innovative Web Product of the Year",
	it:"",
	fr:"",
	de:""
},
//
"On going project:": {
    en: "On going project:",
    ro: "Proiecte in curs:",
	it:"",
	fr:"",
	de:""
},
//
"Co-owner, developer and web designer of www.Camgirl.Cloud, an international project  with Romanian and French collaboration.": {
    en: "Co-owner, developer and web designer of www.Camgirl.Cloud, an international project  with Romanian and French collaboration.",
    ro: "Co-fondator, dezvoltator și web designer al www.Camgirl.Cloud, proiect internațional cu colaborare română și franceză.",
	it:"",
	fr:"",
	de:""
},
//
"Camgirl Live Editor on:": {
    en: "Camgirl Live Editor on:",
    ro: "Camgirl Live Editor:",
	it:"",
	fr:"",
	de:""
},
//
"other industry representatives or individuals": {
    en: "other industry representatives or individuals",
    ro: "alți reprezentanți ai industriei sau persoane fizice",
	it:"",
	fr:"",
	de:""
},
//
"Service Range": {
    en: "Service Range",
    ro: "Prestari Servicii",
	it:"",
	fr:"",
	de:""
},
//
"As mentioned above, on our website we provide high quality web design services at affordable prices.": {
    en: "As mentioned above, on our website we provide high quality web design services at affordable prices.",
    ro: "După cum am menționat mai sus, pe site-ul nostru web oferim servicii de proiectare web de înaltă calitate la prețuri accesibile.",
	it:"",
	fr:"",
	de:""
},
//
"Camgirl Live Editor is a professional tool which allow customization and editing of a wide range of templates from pre designed gallery without writing a single line of code.": {
    en: "Camgirl Live Editor is a professional tool which allow customization and editing of a wide range of templates from pre designed gallery without writing a single line of code.",
    ro: "Camgirl Live Editor este un instrument profesionist care permite personalizarea și editarea designurilor pentru diferite platforme fără cunostinte de programare.",
	it:"",
	fr:"",
	de:""
},
//
"Custom fully editable ready-made bio designs for Chaturbate webcam performers.": {
    en: "Custom fully editable ready-made bio designs for Chaturbate webcam performers.",
    ro: "Design bio personalizat pentru platforma Chaturbate.",
	it:"",
	fr:"",
	de:""
},
//
"Graphics, buttons, code snippets which actually work and they are accepted by Chaturbate platform.": {
    en: "Graphics, buttons, code snippets which actually work and they are accepted by Chaturbate platform.",
    ro: "Elemente grafice, butoanele, fragmentele de cod care funcționează corect și sunt acceptate de platforma Chaturbate.",
	it:"",
	fr:"",
	de:""
},
//
"Custom fully editable ready-made profile designs for MyFreeCams webcam performers.": {
    en: "Custom fully editable ready-made profile designs for MyFreeCams webcam performers.",
    ro: "Proiecte de profil gata modificate personalizate, pregatite pentru utilizatorii MyFreeCams.",
	it:"",
	fr:"",
	de:""
},
//
"Tip Menus with offline tip request puttons, Room Rules, floating icons, pixel perfect graphics and custom editable sections, all to empower performer\'s activity.": {
    en: "Tip Menus with offline tip request puttons, Room Rules, floating icons, pixel perfect graphics and custom editable sections, all to empower performer\'s activity.",
    ro: "Numeroase oportunitati de a mari venitul online din tips offline, tip request, cu sectiuni editabile ce ajuta utilizatorul in activitatea sa.",
	it:"",
	fr:"",
	de:""
},
//
"Other Services": {
    en: "Other Services",
    ro: "Alte Servicii",
	it:"",
	fr:"",
	de:""
},
//
"Niteflirt designs, Cam4 image-based bios, Camsoda bios, custom CamgirlCloud Profile codes and widgets": {
    en: "Niteflirt designs, Cam4 image-based bios, Camsoda bios, custom CamgirlCloud Profile codes and widgets",
    ro: "Bio design pentru Niteflirt, Camsoda, Cam4, coduri marcare pentru profilul CamgirlCloud si altele",
	it:"",
	fr:"",
	de:""
},
//
"Custom themes for CGC Profiles, Wordpress themes, custom plugins": {
    en: "Custom themes for CGC Profiles, Wordpress themes, custom plugins",
    ro: "Teme personalizate pentru CGC, Wordpress, module personalizate (in curand)",
	it:"",
	fr:"",
	de:""
},
//
"Studio Management Platform, Become a CGC Seller, Model's environment and so much more...": {
    en: "Studio Management Platform, Become a CGC Seller, Model's environment and so much more...",
    ro: "Platforma management pentru studiouri, platforma dezvoltare si comert pentru vanzari si multe alte facilitati pentru diferite segmente de consumatori.",
	it:"",
	fr:"",
	de:""
},
//
"Premium - Tailored": {
    en: "Premium - Tailored",
    ro: "Servicii Premium - Personalizari Proiecte",
	it:"",
	fr:"",
	de:""
},
//
"CHOOSE THE PERFECT TAILORED SERVICE": {
    en: "CHOOSE THE PERFECT TAILORED SERVICE",
    ro: "ALEGE SERVICIUL CE SE POTIVESTE PERFECT PROIECTULUI TAU",
	it:"",
	fr:"",
	de:""
},
//
"Take advantage of our many years of experience in providing tailored designs. It\'s really easy, the Lead Designer will ask you questions about your project and the team will build it for you in less than a week.": {
    en: "Take advantage of our many years of experience in providing tailored designs. It\'s really easy, the Lead Designer will ask you questions about your project and the team will build it for you in less than a week.",
    ro: "Profitați de experiența noastra. Este foarte ușor, managerul de proiect îți va pune întrebări despre cerintele tale, iar echipa va lucra pentru tine cu rezultate exceptionale în mai puțin de o săptămână.",
	it:"",
	fr:"",
	de:""
},
//
"Ways to get in touch with us": {
	en: "Ways to get in touch with us",
    ro: "Ne poti contacta prin diferite metode",
	it:"",
	fr:"",
	de:""
},
//
"on Twitter": {
	en: "on Twitter",
    ro: "Pe Twitter",
	it:"",
	fr:"",
	de:""
},
//
"Facebook Group": {
	en: "Facebook Group",
    ro: "Grup Facebook",
	it:"",
	fr:"",
	de:""
},
//
"YouTube Channel": {
	en: "YouTube Channel",
    ro: "Canal YouTube",
	it:"",
	fr:"",
	de:""
},
//
"On Reddit": {
	en: "On Reddit",
    ro: "Pe Reddit",
	it:"",
	fr:"",
	de:""
},
//
"Camgirl Live Editor": {
	en: "Camgirl Live Editor",
    ro: "Camgirl Live Editor",
	it:"",
	fr:"",
	de:""
},


// Help Modal
"Heed Help?": {
	en: "Heed Help?",
    ro: "Ai nevoie de ajutor?",
	it:"",
	fr:"",
	de:""
},
"Change the language of the content using EN (English) or RO (Romanian) options": {
	en: "Change the language of the content using EN (English) or RO (Romanian) options",
    ro: "Shimba continutul in limba Romana (RO) sau Engleza (EN) folosind optiunile afisate",
	it:"",
	fr:"",
	de:""
},
"Icons": {
	en: "Icons",
    ro: "Legenda Iconite",
	it:"",
	fr:"",
	de:""
},
"Contact us if necessary": {
	en: "Contact us if necessary",
    ro: "Daca este necesar ne poti contacta",
	it:"",
	fr:"",
	de:""
},
"Close": {
	en: "Close",
    ro: "Inchide",
	it:"",
	fr:"",
	de:""
},
"Using external style sheet (MyFreeCams)": {
	en: "Using external style sheet (MyFreeCams)",
    ro: "MyFreeCams si foaia de stil externa",
	it:"",
	fr:"",
	de:""
},
"Because MyFreeCams allows additional css, when using the Editor Tool, wrap the CSS markup between": {
	en: "Because MyFreeCams allows additional css, when using the Editor Tool, wrap the CSS markup between",
    ro: "Deoarece MyFreeCams foloseste foaie de stil externa, in Editor va trebui sa adaugi si css-ul intre etichetele",
	it:"",
	fr:"",
	de:""
},
"and": {
	en: "and",
    ro: "si",
	it:"",
	fr:"",
	de:""
},
"tags followed by HTML markup": {
	en: "tags followed by HTML markup",
    ro: "urmat de codul HTML",
	it:"",
	fr:"",
	de:""
},
"Should look like this, inside the Editor tool": {
	en: "Should look like this, inside the Editor tool",
    ro: "In Editor ar trebui sa arate similar cu",
	it:"",
	fr:"",
	de:""
},

//Render Source 
//26 
 "Test markup codes and see how your browser is rendering them. Use": {
    en: "Test markup codes and see how your browser is rendering them. Use",
    ro: "Testați codurile de marcare și vedeți cum le redă browserul. Foloseste butonul",
	it:"",
	fr:"",
	de:""
  },
//27  
 "button to see how to use the source editor and rendering tool": {
    en: "button to see how to use the source editor and rendering tool",
    ro: "pentru a vedea mai multe informatii cum sa folosesti aceasta functie",
	it:"",
	fr:"",
	de:""
  },
//28    
"Markup Code Box": {
    en: "Markup Code Box",
    ro: "Caseta Cod Marcaj",
	it:"",
	fr:"",
	de:""
  },
//29     
"Show": {
    en: "Show",
    ro: "Arata",
	it:"",
	fr:"",
	de:""
  },
//30    
"Default": {
    en: "Default",
    ro: "Implicit",
	it:"",
	fr:"",
	de:""
  },
//31   
"Render Box": {
    en: "Render Box",
    ro: "Caseta Redare",
	it:"",
	fr:"",
	de:""
  },
//32  
 "That\'s how it looks rendered in browser. Optionally you can": {
    en: "That\'s how it looks rendered in browser. Optionally you can",
    ro: "Asa arata in browser. Optional",
	it:"",
	fr:"",
	de:""
  },
//33  
 "Save as PDF": {
    en: "Save as PDF",
    ro: "Salveaza ca PDF",
	it:"",
	fr:"",
	de:""
  },
//34         
"Default button, on click, removes the markup code from grey box above": {
    en: "Default button, on click, removes the markup code from grey box above",
    ro: "Butonul Implicit, sterge codul din caseta cu sursa codului",
	it:"",
	fr:"",
	de:""
  },  
  
 //39
 "How to use...": {
    en: "How to use...",
    ro: "Cum sa folosesti...",
	it:"",
	fr:"",
	de:""
  },
//40  
 "Paste markup codes showed on page inside the Markup Code Box (top box)": {
    en: "Paste markup codes showed on page inside the Markup Code Box (top box)",
    ro: "Adauga codul de marcaj in caseta din stanga, Caseta Cod Marcaj",
	it:"",
	fr:"",
	de:""
  },
//41     
 "Click on Show button": {
    en: "Click on Show button",
    ro: "Click pe butonul Arata",
	it:"",
	fr:"",
	de:""
  },
//42   
 "View the rendered markup inside the Render Box (below)": {
    en: "View the rendered markup inside the Render Box (below)",
    ro: "In caseta din dreapta, Caseta Redare, poti vedea cum este interpretat de catre browser codul sursa",
	it:"",
	fr:"",
	de:""
  },
//43     
 "Show button allows you to start rendering the markup code": {
    en: "Show button allows you to start rendering the markup code",
    ro: "Butonul Arata, vă permite să începeți redarea codului de marcare",
	it:"",
	fr:"",
	de:""
  },
//44     
"Default button is used as reset the Markup Code box, all input will be lost": {
    en: "Default button is used as reset the Markup Code box, all input will be lost",
    ro: "Butonul Implicit este utilizat ca resetare a casetei Cod de Marcaj, continutul din aceasta fereastra va fi sters",
	it:"",
	fr:"",
	de:""
  },
//45    
"Print this page as pdf - well, you don\'t need much but its there, just in case. Please note, the print page will only print content from Render Box.": {
    en: "Print this page as pdf - well, you don\'t need much but its there, just in case. Please note, the print page will only print content from Render Box.",
    ro: "Salveaza ca pdf - ei bine, nu este nevoie, dar este acolo. Vă rugăm, rețineți, pagina de imprimare va imprima doar conținut din Caseta Redare.",
	it:"",
	fr:"",
	de:""
  },   
//
"Close": {
    en: "Close",
    ro: "Inchide",
	it:"",
	fr:"",
	de:""
  }, 
  
//Modal Translate
  "Change Language": {
	en: "Change Language",
    ro: "Schimba limba",
	it:"Cambia lingua",
	fr:"Changer de langue",
	de:""
  },
  
   "Change the content of the material in your preferred language": {
    en: "Change the content of the material in your preferred language",
	ro: "Schimba continutul materialului in limba preferata",
	it:"Cambia il contenuto del materiale nella tua lingua preferita",
	fr:"Changer le contenu du matériel dans votre langue préférée",
	de:""
  },
  
  "Romanian": {
    en: "Romanian",
    ro: "Romana",
	it: "Rumena",
	fr: "Roumaine",
	de: "Rumänische"
  },
  "English": {
    en: "English",
	ro: "Engleza",
	it: "Inglese",
	fr: "Anglaise",
	de: "Englische"
  },
  
 "French": {
	en: "French",
    ro: "Franceza",
	it: "Francese",
	fr: "Français",
	de: "Französische"
  },
   
   "Italian": {
    en: "Italian",
	ro: "Italiana",
	it: "Italiano",
	fr: "Italien",
	de: "Italienisch"
  },
  "German": {
    en: "German",
    ro: "Germana",
	it: "Tedesca",
	fr: "Allemand",
	de: "Deutsch"
  },  
  
 "Help translate this material": {
    en:"Help translate this material",
	ro:"Ajuta la traducerea acesui material",
	it:"Aiuta a tradurre questo materiale",
	fr:"Aidez à traduire ce matériel",

	de:"Hilf mit, dieses Material zu übersetzen"
  },  

}
  
  
  
  var _t = $('body').translate({lang: "en", t: t});
  var str = _t.g("translate");
  console.log(str);


  $(".lang_selector").click(function(ev) {
    var lang = $(this).attr("data-value");
    _t.lang(lang);

    console.log(lang);
    ev.preventDefault();
  });



});



    
    

