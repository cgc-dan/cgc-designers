$(function() {

  var t = { 

"Info": {
    en: "Info",
    ro: "Info",
	it:"",
	fr:"",
	de:""
  },
// 
"Hello": {
    en: "Hello",
    ro: "Buna",
	it:"",
	fr:"",
	de:""
  },
//
"Thank you for your interest in our Camgirl.Cloud services.": {
    en: "Thank you for your interest in our Camgirl.Cloud services.",
    ro: "Multumim pentru interesul acordat serviciului nostru Camgirl.Cloud.",
	it:"",
	fr:"",
	de:""
  },
//
"To show our appreciation we\'ve put together a Giveaway Bundle for free download and use.": {
    en: "To show our appreciation we\'ve put together a Giveaway Bundle for free download and use.",
    ro: "Pentru a ne arăta aprecierea, am creat un pachet pentru descărcare și utilizare gratuită.",
	it:"",
	fr:"",
	de:""
  },
//  
  "pack includes a custom Chaturbate Bio design, a MyFreeCams profile design, a Niteflirt Bio design and an OBS overlay.": {
    en: "pack includes a custom Chaturbate Bio design, a MyFreeCams profile design, a Niteflirt Bio design and an OBS overlay.",
    ro: "contine un design personalizat pentru platforma Chaturbate, un design pentru site-ul MyFreeCams, un design bio pentru Niteflirt si cod pentru OBS.",
	it:"",
	fr:"",
	de:""
  }, 
// 
  "All resources included in this package are well documented, includes the markup language and graphic elements.": {
	en: "All resources included in this package are well documented, includes the markup language and graphic elements.",
    ro: "Pachetul contine toate resursele grafice, documentatia necesara editarii sursei si indicatiile specifice fiecarui kit.",
	it:"",
	fr:"",
	de:""
  },   
//
  "view": {
    en: "view",
    ro: "vezi",
	it:"",
	fr:"",
	de:""
  },

//
"Markup code": {
    en: "Markup code",
    ro: "Sursa cod de marcare",
	it:"",
	fr:"",
	de:""
  },
//
"All designs come with their own custom markup codes, please don\'t try to combine code snippets between designs or try to install a custom design for one platform to another platform. They are build and developed specifically for their respective service.": {
    en: "All designs come with their own custom markup codes, please don\'t try to combine code snippets between designs or try to install a custom design for one platform to another platform. They are build and developed specifically for their respective service.",
    ro: "Toate pachetele vin cu propriile coduri de marcare personalizate, nu încercați să combinați fragmente de cod între proiecte sau să încercați să instalați un design personalizat pentru o platformă pe o altă platformă. Sunt construite și dezvoltate special pentru serviciile respective.",
	it:"",
	fr:"",
	de:""
  },
//
"Graphic resources": {
    en: "Graphic resources",
    ro: "Resurse grafice",
	it:"",
	fr:"",
	de:""
  },
// 
"Even if this package is a free one, you need to host images.": {
    en: "Even if this package is a free one, you need to host images.",
    ro: "Chiar dacă acest pachet este unul gratuit, trebuie să găzduiești imagini.",
	it:"",
	fr:"",
	de:""
},
//
"Each design comes with their image folder. Upload your graphics online, copy and replace the full url path inside the source markup.": {
    en: "Each design comes with their image folder. Upload your graphics online, copy and replace the full url path inside the source markup.",
    ro: "Fiecare design vine cu folderul sau de resurse. Încărcați imaginile online, copiați și înlocuiți calea URL completă in marcajul sursă.",
	it:"",
	fr:"",
	de:""
  },
//
"Source editor": {
	en: "Source editor",
    ro: "Editor sursa cod",
	it:"",
	fr:"",
	de:""
  },
//
"If you are not familiar with markup editing or have no WYSIWYG markup editor installed on your machine, the Source Editor might be helpful becaus it allows you to see the markup code and edit it accordingly; ther\'s also a Preview function which renders your editing process in live browser based output.": {
	en: "If you are not familiar with markup editing or have no WYSIWYG markup editor installed on your machine, the Source Editor might be helpful becaus it allows you to see the markup code and edit it accordingly; ther\'s also a Preview function which renders your editing process in live browser based output.",
    ro: "Dacă nu sunteți familiarizat cu editarea marcajului sau nu aveți niciun editor de marcare WYSIWYG instalat pe laptopul/pc-ul dvs., Editorul Sursă poate fi util, deoarece vă permite să vedeți codul de marcare și să îl editați în consecință; de asemenea există și o funcție Previzualizare care redă din procesul de editare în browser.",
	it:"",
	fr:"",
	de:""
},

// Help Modal
"Heed Help?": {
	en: "Heed Help?",
    ro: "Ai nevoie de ajutor?",
	it:"",
	fr:"",
	de:""
},
"Change the language of the content using EN (English) or RO (Romanian) options": {
	en: "Change the language of the content using EN (English) or RO (Romanian) options",
    ro: "Shimba continutul in limba Romana (RO) sau Engleza (EN) folosind optiunile afisate",
	it:"",
	fr:"",
	de:""
},
"Icons": {
	en: "Icons",
    ro: "Legenda Iconite",
	it:"",
	fr:"",
	de:""
},
"Contact us if necessary": {
	en: "Contact us if necessary",
    ro: "Daca este necesar ne poti contacta",
	it:"",
	fr:"",
	de:""
},
"Close": {
	en: "Close",
    ro: "Inchide",
	it:"",
	fr:"",
	de:""
},




    
// Footer
"app v: 1.0": {
	en: "app v: 1.0",
    ro: "versiune: 1.0",
	it:"",
	fr:"",
	de:""
}, 
         
//Modal Translate - Not Provided
  "Change Language": {
	en: "Change Language",
    ro: "Schimba limba",
	it:"Cambia lingua",
	fr:"Changer de langue",
	de:""
  },
  
   "Change the content of the material in your preferred language": {
    en: "Change the content of the material in your preferred language",
	ro: "Schimba continutul materialului in limba preferata",
	it:"Cambia il contenuto del materiale nella tua lingua preferita",
	fr:"Changer le contenu du matériel dans votre langue préférée",
	de:""
  },
  
  "Romanian": {
    en: "Romanian",
    ro: "Romana",
	it: "Rumena",
	fr: "Roumaine",
	de: "Rumänische"
  },
  "English": {
    en: "English",
	ro: "Engleza",
	it: "Inglese",
	fr: "Anglaise",
	de: "Englische"
  },
  
 "French": {
	en: "French",
    ro: "Franceza",
	it: "Francese",
	fr: "Français",
	de: "Französische"
  },
   
   "Italian": {
    en: "Italian",
	ro: "Italiana",
	it: "Italiano",
	fr: "Italien",
	de: "Italienisch"
  },
  "German": {
    en: "German",
    ro: "Germana",
	it: "Tedesca",
	fr: "Allemand",
	de: "Deutsch"
  },  
  
 "Help translate this material": {
    en:"Help translate this material",
	ro:"Ajuta la traducerea acesui material",
	it:"Aiuta a tradurre questo materiale",
	fr:"Aidez à traduire ce matériel",

	de:"Hilf mit, dieses Material zu übersetzen"
  },  

}
  
  
  
  var _t = $('body').translate({lang: "en", t: t});
  var str = _t.g("translate");
  console.log(str);


  $(".lang_selector").click(function(ev) {
    var lang = $(this).attr("data-value");
    _t.lang(lang);

    console.log(lang);
    ev.preventDefault();
  });



});



    
    

